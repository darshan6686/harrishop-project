import { PRODUCT_LIST } from "../Type";

export let productList = () => {
    return{
        type: PRODUCT_LIST,
    }
}